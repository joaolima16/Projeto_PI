package com.example.projeto_pi.pi.Record;

public record UserRecord(String email, String password){

}
