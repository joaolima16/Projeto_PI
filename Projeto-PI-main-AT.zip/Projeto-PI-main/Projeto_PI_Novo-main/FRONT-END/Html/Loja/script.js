async function carregarProdutos(){
    let arrProducts = [];
    var url = "http://localhost:8080/product"
    await fetch(url)
    .then((response) => response.json())
    .then((res) => arrProducts = res)
    .catch((error) => console.log(error))
    arrProducts.forEach((index) =>{
        let div = document.createElement("div");
        let h3 = document.createElement("h3");
     
        h3.textContent = `${index.name}`;
        div.classList.add("box")
        div.appendChild(h3);
        document.body.appendChild(div);
      
        })
}