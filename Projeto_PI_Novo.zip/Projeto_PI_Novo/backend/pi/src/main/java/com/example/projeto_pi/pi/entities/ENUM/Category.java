package com.example.projeto_pi.pi.entities.ENUM;

public enum Category{
    PERIFERICO, 
    COMPUTADOR,
    SMARTPHONE,

}
