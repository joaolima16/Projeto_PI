let list = document.querySelector('.slider .list');
let itens = document.querySelector('.slider .list .item');
let dots = document.querySelector('.slider .dots li');
let anterior = document.querySelector('anterior');
let prox = document.querySelector('prox');

let ativo = 0;
let lengthItens= itens.length;

prox.onclick = function(){
   if(ativo + 1 > lengthItens){
    ativo =0;
   }else{
    ativo = ativo+ 1;
   }
    reloadSlider();
}

anterior.onclick = function(){
    if(ativo -1<0){
        ativo = lengthItens;
    }else{
        ativo = ativo-1
    }
    reloadSlider();
}

let refreshSlider = setInterval(()=> {prox.click()},300);
function reloadSlider () {
    let checkLeft = itens[ativo].offsetLeft;
    list.style.left = -checkLeft + 'px';

    let lastActivionDotws = document.querySelector('.slider .dots li.ativo');
    lastActivionDotws.classList.remove('ativo');
    dots[ativo].classList.add('ativo');
    clearInterval(refreshSlider);
    refreshSlider = setInterval(()=> {prox.click()},300);
}

dots.forEach((li,key)) => {
    li.addEventListener('click', function(){
        ativo = key;
        reloadSlider();
    })
}