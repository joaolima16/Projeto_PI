package com.example.projeto_pi.pi.usecases;

import com.example.projeto_pi.pi.entities.Product;

public class ItemSaleCase {
    public void RegisterItemsSale(Product[] products){
        
    }
}
